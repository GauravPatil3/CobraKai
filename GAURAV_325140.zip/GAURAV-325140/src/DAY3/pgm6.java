package DAY3;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="I ma learning java";
		int l=str.length();
		System.out.println("Lenght is"+l);
		
		System.out.println(str.indexOf('l'));
		
		System.out.println(str.indexOf('a', 5));
		System.out.println(str.substring(3,8));
		
		
	}

}
