package DAY3;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="I ma learning java";
		int c=0,p=0;
		while(p!=-1) {
			p=str.indexOf(" ",p+1);
			c++;
		}
	System.out.println(c);
	}
	

}
