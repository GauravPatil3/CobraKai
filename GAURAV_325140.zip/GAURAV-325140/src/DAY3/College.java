package DAY3;

public class College {

	public static void main(String[] args) {
		Student Rakesh=new Student();
		Rakesh.rollno=34;
		Rakesh.m1=23;
		Rakesh.m2=45;
		Rakesh.name="Rakesh";
		
		Student Priya=new Student();
		Priya.rollno=45;
		Priya.m1=67;
		Priya.m2=90;
		Priya.name="Priya";
		
		System.out.println("Roll Number is:"+Rakesh.rollno);
		System.out.println("Marks of Rakesh:"+Rakesh.m1);
		System.out.println("Marks of Rakesh:"+Rakesh.m2);
		System.out.println("Name is:"+Rakesh.name);
		Rakesh.average(Rakesh.m1,Rakesh.m2);
		
		System.out.println("Roll Number of Priya is:"+Priya.rollno);
		System.out.println("Marks of Priya:"+Priya.m1);
		System.out.println("Marks of Priya:"+Priya.m2);
		System.out.println("Name is:"+Priya.name);
		Priya.average(Priya.m1,Priya.m2);
		
			

	}

}
