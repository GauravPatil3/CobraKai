package DAY3;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int std[]= {77,55,79,6,92,91};
		int sum=0;
		float avg;
		for(int i=0;i<std.length;i++) {
			sum=sum+std[i];
		}
		
		avg=(float)sum/6;
		System.out.printf("%.2f",avg);
	}

}
