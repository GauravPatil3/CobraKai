package DAY3;

public class pgm4 {

	public static void maxx(int[]s) {
		int max=-1;
		for(int i=0;i<s.length;i++) {
			for(int j=i+1;j<s.length;j++) {
				if(s[i]>s[j]) {
					if(max<s[i])
					max=s[i];
				}
				else {
					if(max<s[j])
					max=s[j];
				}
					
			}
		}
		System.out.println("max element is:"+max);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int marks[][]= {{108,94,124,23},{56,78,3,1},{4,5,6,7}};
		for(int a[]:marks)
		{
			for(int i=0;i<a.length;i++)
				System.out.print(a[i]+" ");
			System.out.println();
			maxx(a);
		}

}
}