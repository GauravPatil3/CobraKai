package DAY2;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=15,sum=0;
		while(i<=75) {
			if(i%7==0)
			{
				sum=sum+i;
			}
			i++;
		}
		System.out.println(sum);
	}

}
