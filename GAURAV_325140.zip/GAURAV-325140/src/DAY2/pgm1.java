package DAY2;

import java.util.Scanner;
import java.io.PrintStream ;
public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
	//	 String a=String.valueOf(num);
		 
		
		
		
		switch(num)
		{
		case 1:
			System.out.println("one");
			break;
		case 2:
			System.out.println("two");
			break;
		case 3:
			System.out.println("three");
			break;
		case 4:
			System.out.println("four");
			break;
		default:
			System.out.println("Bad Choice");
		
		}
		
		sc.close();
		
	}

}
