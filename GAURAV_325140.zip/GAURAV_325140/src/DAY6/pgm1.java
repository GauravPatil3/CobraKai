package DAY6;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str[]= {"global","Logic","Noida"};
		for(String out:str) {
			System.out.println(out);
		}
	}

}
