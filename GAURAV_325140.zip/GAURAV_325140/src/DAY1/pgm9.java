package DAY1;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10,b=12;
if(b>a)
	System.out.println("a is less than b");
else
	System.out.println("b is greater than a OR b is equal to a");
	}

}
