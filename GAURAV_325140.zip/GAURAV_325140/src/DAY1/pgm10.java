package DAY1;

//import java.util.Scanner;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char str='a';
		char str1='w';
		//Scanner sc=new Scanner(System.in);
		// char str4=sc.next().charAt(0);
		if(str=='a'||str=='e'||str=='i'||str=='o'||str=='u')
		{
			System.out.println("Is a Vowel");
		}
		else
		{
			System.out.println("Not a Vowel");
		}
		if(str1=='a'||str1=='e'||str1=='i'||str1=='o'||str1=='u')
		{
			System.out.println("Is a Vowel");
		}
		else
		{
			System.out.println("Not a Vowel");
		}	
	}

}
