package Hybrid_fm;

public class tc_selection {

	
	public String tcid;
	public String flag;
	public int no_steps;
	public String test_data_sh;
}
