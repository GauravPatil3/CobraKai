package Hybrid_fm;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_read {
	static tc_selection sdata;
	
	static keyword_sh kdata;
	public static ArrayList<login_test_data> list=new ArrayList<login_test_data>();
	
	public static void write_excel( int i,String str) {
		
		try {
			File f=new  File("hybrid.xlsx");
			FileInputStream fi=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi);
			XSSFSheet sh=wb.getSheet("TC_SELECTION");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.createCell(4);
			c.setCellValue(str);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		}
	catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

		
	}
	public static tc_selection read_sheet(int i) {
		// TODO Auto-generated method stub
		sdata=new tc_selection();
		kdata=new keyword_sh();

		try {
			File f=new  File("hybrid.xlsx");
			FileInputStream fi=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi);
			XSSFSheet sh=wb.getSheet("TC_SELECTION");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(0);
			sdata.tcid=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			sdata.flag=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			sdata.no_steps=(int) c2.getNumericCellValue();
			
			if(r.getCell(3)==null||r.getCell(3).getCellType()==Cell.CELL_TYPE_BLANK) {
				sdata.test_data_sh=null;
			}else
				sdata.test_data_sh=r.getCell(3).getStringCellValue();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return sdata;
	}
	
	public static keyword_sh read_keyword_sh(int j) {
		// TODO Auto-generated method stub

		try {
			File f=new  File("hybrid.xlsx");
			FileInputStream fi=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi);
			XSSFSheet sh=wb.getSheet("KEYWORD");
			XSSFRow r=sh.getRow(j);
			XSSFCell c=r.getCell(0);
			kdata.TC_ID=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			kdata.step_no=(String) c1.getStringCellValue();
		
			
			if(r.getCell(3)==null||r.getCell(3).getCellType()==Cell.CELL_TYPE_BLANK) {
				kdata.KeyWord=null;
			}else
				kdata.KeyWord=r.getCell(3).getStringCellValue();
			
			if(r.getCell(4)==null||r.getCell(4).getCellType()==Cell.CELL_TYPE_BLANK) {
				kdata.Xpath=null;
			}else
				kdata.Xpath=r.getCell(4).getStringCellValue();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return kdata;
	}

	public static void get_test_data(String test_data_sh) {
		
		int m=1;
		// TODO Auto-generated method stub
		
		try {
			File f=new  File("hybrid.xlsx");
			FileInputStream fi=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi);
			XSSFSheet sh=wb.getSheet(test_data_sh);
			for(int i=1;i<=m;i++) {
			m=sh.getLastRowNum();
			login_test_data p=new login_test_data();
			
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(0);
			p.uid=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			p.pwd=(String) c1.getStringCellValue();
			list.add(p);
		}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
