package SDAY2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm3 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.w3schools.com/html/html_tables.asp");
	
		for(int r=2;r<=7;r++) {
			for(int c=1;c<=3;c++) {
		String s1=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+ r +"]/td["+ c +"]")).getText();
		System.out.print(s1);
		System.out.print("              ");
			}
		System.out.println();
		}
		
		
				
	}

}
