package SDAY2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm2 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		dr.findElement(By.id("email")).sendKeys("7030768769");
		dr.findElement(By.id("pass")).sendKeys("gaurav@2");
		//dr.findElement(By.xpath("//*[@id=\"u_0_b\"]")).click();
		dr.findElement(By.id("u_0_b")).click();
		
		WebElement we1=dr.findElement(By.id("day"));
		Select sel1=new Select(we1);
		sel1.selectByVisibleText("1");
		
		WebElement we2=dr.findElement(By.id("month"));
		Select sel2=new Select(we2);
		sel2.selectByVisibleText("May");
		
		WebElement we3=dr.findElement(By.id("year"));
		Select sel3=new Select(we3);
		sel3.selectByVisibleText("1997");
		
		List<WebElement> rb=dr.findElements(By.name("sex"));
		((WebElement)rb.get(0)).click();
		
		
		
		String s=dr.findElement(By.className("_1vp5")).getText();
		if(s.equals("Gaurav")) {
			System.out.println("Successful");
		}

	}

}
