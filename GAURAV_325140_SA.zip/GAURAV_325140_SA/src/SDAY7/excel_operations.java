package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Hybrid_fm.keyword_sh;
import Hybrid_fm.tc_selection;

public class excel_operations {

static String out;
static Test_selection sdata=new Test_selection(); 
static keyword kdata=new keyword();
public static Test_selection read_sheet1(int i) {

	try {
		File f=new  File("exc.xlsx");
		FileInputStream fi=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fi);
		XSSFSheet sh=wb.getSheet("tc");
		XSSFRow r=sh.getRow(i);
		
		XSSFCell c=r.getCell(0);
		System.out.println(c.getStringCellValue());
		sdata.tcid=c.getStringCellValue();
		XSSFCell c1=r.getCell(1);
		sdata.flag=c1.getStringCellValue();
		XSSFCell c2=r.getCell(2);
		sdata.no_steps=(int) c2.getNumericCellValue();
		
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return sdata;
}

public static keyword read_keyword_s(int j) {
	// TODO Auto-generated method stub

	try {
		File f=new  File("exc.xlsx");
		FileInputStream fi=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fi);
		XSSFSheet sh=wb.getSheet("Sheet1");
		XSSFRow r=sh.getRow(j);
		XSSFCell c=r.getCell(0);
		kdata.TC_ID=c.getStringCellValue();
		XSSFCell c1=r.getCell(1);
		kdata.step_no=(String) c1.getStringCellValue();
	
		
		if(r.getCell(2)==null||r.getCell(2).getCellType()==Cell.CELL_TYPE_BLANK) {
			kdata.KeyWord=null;
		}else
			kdata.KeyWord=r.getCell(2).getStringCellValue();
		
		if(r.getCell(3)==null||r.getCell(3).getCellType()==Cell.CELL_TYPE_BLANK) {
			kdata.Xpath=null;
		}else
			kdata.Xpath=r.getCell(3).getStringCellValue();
		
		if(r.getCell(4)==null||r.getCell(4).getCellType()==Cell.CELL_TYPE_BLANK) {
			kdata.Test_data=null;
		}else
			kdata.Test_data=r.getCell(4).getStringCellValue();
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return kdata;
}









	public static String read_excel(int r,int c){
		int last;
		
		try {
			File f=new File("exc.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			
			XSSFRow r1=sh.getRow(r);
			XSSFCell c1=r1.getCell(c);
			 out =c1.getStringCellValue();
		
		}
			catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
		return out;
	
	}
	public void write_excel(int r) {

		try {
			File f=new File("exc.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			
			XSSFRow r1=sh.getRow(r);
			XSSFCell c1=r1.createCell(5);
			c1.setCellValue("Success");
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		}
			catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	

	public static void write_excel1( int i,String str) {
		
		try {
			File f=new  File("exc.xlsx");
			FileInputStream fi=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fi);
			XSSFSheet sh=wb.getSheet("tc");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.createCell(3);
			c.setCellValue(str);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		}
	catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	
}
}
