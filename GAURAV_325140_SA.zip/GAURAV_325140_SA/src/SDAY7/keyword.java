package SDAY7;

public class keyword {
public String TC_ID;
public String step_no;
public String KeyWord;
public String Xpath;
public String Test_data;
}
