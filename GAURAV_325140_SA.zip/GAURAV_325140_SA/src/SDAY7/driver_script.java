package SDAY7;

import org.openqa.selenium.WebDriver;

import SDAY7.excel_operations;
import SDAY7.keyword;

public class driver_script extends excel_operations {


	public static void main(String args[]) {
		String kw,loc,td;
		int r = 0;
		WebDriver dr=null;
		all_webelement_fns1 we=new all_webelement_fns1(dr);
		Test_selection tcs=new  Test_selection();
		keyword  ksh=new keyword();
		int i,j = 0;
		
		for(i=1;i<=3;i++) {
			
			tcs =read_sheet1(i);
			//System.out.println(tcs.flag);
			
			if(tcs.flag.equals("Y")) {
				
				
						for(j=1;j<20;j++) {
							
							
							ksh=read_keyword_s(j);
						
							if(tcs.tcid.equals(ksh.TC_ID)) {
						
								System.out.println("found");
								break;
							}
							
							else
							{
								continue;
								
								
							}
						}
						

						for( r=j;r<=(j+tcs.no_steps-1);r++) {
							kw= excel_operations.read_excel(r,2);
							loc=excel_operations.read_excel(r,3);
							td=excel_operations.read_excel(r,4);
							
							switch(kw)
							{
							case "launchchrome":
								we.launchChrome(td);
								break;
								
							case "enter_txt" :
								we.enter_txt(loc,td);
								break;
							
							case "click_btn" :
								we.click(loc);
								break;
								
							case "click_link":
								we.clicklink(loc);
								break;
							case "click_rb":
								we.clickrb(loc);
								break;
							case "Verify":
								we.verify(loc,td,r);
								break;
							case "closechrome":
								we.closee();
							}
						}
					
							
								
							}
							
							if(r==(j+tcs.no_steps))
							{
								System.out.println("pass");
								write_excel1(i,"Pass");
							}
							else
							{
								if(tcs.flag.equals("N"))
									continue;
								System.out.println("fail");
								write_excel1(i,"Fail");
							}
						
				
						}
			
			}
			
			
		
	
	}


