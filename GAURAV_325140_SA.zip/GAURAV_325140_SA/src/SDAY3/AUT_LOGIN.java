package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AUT_LOGIN {

	public static excel_io ei=new excel_io();
	public static excel_io read_excel() {
		
		try {
			File f=new File("Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c1=r.getCell(0);
		ei.uid=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(1);
			int q=(int) c2.getNumericCellValue();
			//ei.pass=	c2.getRawValue();
		//	System.out.println(c2.getCellType());
			//System.out.println(ei.pass);
			ei.pass=Integer.toString(q); 
			
			XSSFCell c3=r.getCell(2);
			ei.exp_res=c3.getStringCellValue();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ei;
	}
	
	public static void login() {

		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.name("Email")).sendKeys(ei.uid);
		dr.findElement(By.name("Password")).sendKeys(ei.pass);
		//dr.findElement(By.className("button-1 login-button")).click();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
	String str=	dr.findElement(By.className("account")).getText();
	if(str.equals(ei.uid)) {
		ei.act_res="Valid";
		System.out.println("pass");
	}else {
		ei.act_res="fail";
		System.out.println("fail");
		
	}}
	
	public static void write_excel() {

		try {
			File f=new File("Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			XSSFRow r=sh.getRow(1);
			if(ei.act_res.equals(ei.exp_res)) {
				ei.status=ei.act_res;
			
			XSSFCell c1=r.createCell(3);
			c1.setCellValue(ei.act_res);
			
			XSSFCell c2=r.createCell(4);
			c2.setCellValue(ei.status);
			}
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public static void main(String[] args) {
		
		excel_io e1=read_excel();
		login();
		write_excel();

	}

}
