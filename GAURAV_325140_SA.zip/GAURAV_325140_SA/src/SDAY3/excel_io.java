package SDAY3;

public class excel_io {

	
	String uid,pass,exp_res,act_res,status;

}
