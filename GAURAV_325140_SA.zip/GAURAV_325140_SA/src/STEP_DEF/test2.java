package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test2 {
WebDriver dr;



@When("^User enters invalid login data$")
public void user_enters_login_data_and_clicks_ok_button() throws Throwable {
	dr=test1.dr;
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	dr.findElement(By.id("Email")).sendKeys("cobrakai134@gmail.com");
	dr.findElement(By.id("Password")).sendKeys("12346g");
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
}

@Then("^Login is not successful$")
public void home_page_is_displayed() throws Throwable {
	dr=test1.dr;
	String str=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
   String str2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
	Thread.sleep(20);
  String s1=" Login was unsuccessful. Please correct the errors and try again.";
  String s2="No customer account found";
   dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
   System.out.println(str);
   SoftAssert sa=new  SoftAssert();
  
   sa.assertEquals(str, s1);
   sa.assertEquals(str2, s2);
   System.out.println("Success");
   sa.assertAll();
   dr.close();
}
}
