package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class pgm2_homepage {

	WebDriver dr;

	public pgm2_homepage(WebDriver dr) {
		this.dr=dr;
	}


	public String addcart(int i) {
		dr.findElement(By.xpath("//div[@class=\"inventory_item\"]["+i+"]//button")).click();
		String str1=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		return str1;
	}


	public void cickcart() {
		dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
		
		
	}

}
