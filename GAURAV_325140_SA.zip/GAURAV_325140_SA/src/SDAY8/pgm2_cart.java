package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class pgm2_cart {

	

	private WebDriver dr;

	public pgm2_cart(WebDriver dr) {

		this.dr=dr;
	}

	public String verify() {
		String str=dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		return str;
		
	}
}
