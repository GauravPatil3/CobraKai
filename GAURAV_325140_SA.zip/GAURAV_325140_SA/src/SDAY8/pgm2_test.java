package SDAY8;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class pgm2_test {
	WebDriver dr;
	pgm2_login lp;
	pgm2_homepage hp;
	pgm2_cart c;
  @Test
  public void test() {
	  lp.do_login("standard_user","secret_sauce");
	  
	 String str1= hp.addcart(1);
	  hp.cickcart();
	  String str=c.verify();
	  SoftAssert sa=new SoftAssert();
	 
		sa.assertEquals(str,str1);
	 System.out.println("Success");
	  sa.assertAll();
  }
  @BeforeClass
  public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	  dr=new ChromeDriver();
	  dr.get("https://www.saucedemo.com/");
		
		 lp=new pgm2_login(dr);
		 hp=new pgm2_homepage(dr);
		 c=new pgm2_cart(dr);
		
  }

}
