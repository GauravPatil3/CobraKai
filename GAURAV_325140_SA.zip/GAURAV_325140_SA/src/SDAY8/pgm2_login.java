package SDAY8;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class pgm2_login {
WebDriver dr;
	public pgm2_login(WebDriver dr) {
		this.dr=dr;
	}
	public void do_login(String id,String pass) {
		dr.findElement(By.id("user-name")).sendKeys(id);
		dr.findElement(By.id("password")).sendKeys(pass);
		dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();
		
	}
}
