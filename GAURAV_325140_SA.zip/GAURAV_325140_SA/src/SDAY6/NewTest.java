package SDAY6;

import org.testng.annotations.Test;

public class NewTest {
  @Test(priority=0)
  public void c() {
	  System.out.println("In c");
	  
  }
  @Test(priority=2)
  public void b() {
	  System.out.println("In b");
	
  }
  @Test(priority=3)
  public void a() {
	  System.out.println("In a");
	  
  }
}
