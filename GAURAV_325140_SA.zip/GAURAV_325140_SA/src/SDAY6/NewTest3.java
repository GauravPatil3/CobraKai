package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY4.data;
import SDAY4.login;

public class NewTest3 {
  @Test
  public void t1() {
	  
	  
	  data d=new data();
	  d.uid="cobrakai123@gmail.com";
	  d.pwd="123456";
	  d.exp_res="Pass";
	  data d1=login.llogin(d);
	  SoftAssert sa=new SoftAssert();
	   sa.assertEquals(d.exp_res,d1.actual_res);
	  System.out.println(d1.actual_em1+"\n"+d1.actual_em2);
	  sa.assertAll();
  }
  
  @Test
  public void t2() {
	  data d=new data();
	  d.uid="hh@gmail.com";
	  d.pwd="ggggaa";
	  d.exp_res="Success";
	  d.exp_em1="Login was unsuccessful. Please correct the errors and try again.";
	  d.exp_em2="The credentials provided are incorrect";
	  data d1=login.llogin(d);
	  SoftAssert sa=new SoftAssert();
	   sa.assertEquals(d.exp_res,d1.actual_res);
	  System.out.println(d1.actual_em1+"\n"+d1.actual_em2);
	  sa.assertAll();
	  
  }
  
}
