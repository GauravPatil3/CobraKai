package SDAY6;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class NewTest4 {
  @Test(dataProvider = "dp")
  public void f(String u,String p,String er) {
	 
	  System.out.println("login : "+ u +" "+ p+" " +er);
  }

  @DataProvider
  public String[][] dp() {
	
	  String obj[][]= {{"uid1","pwd1","er1"},{"uid2","pwd2","er2"}};
    return obj; 
     
    }
  }

