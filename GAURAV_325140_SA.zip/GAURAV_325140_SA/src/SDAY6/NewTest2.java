package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest2 {
	 @Test(priority=0)
	  public void c() {
		 String ar="noida",er="noida";
		 //hardAssert
		 Assert.assertEquals(ar, er);
		  System.out.println("In c");
		  
	  }
	  @Test(priority=2)
	  public void b() {
		  String ar="noida",er="noida1";
		  //hardAssert
			 Assert.assertEquals(ar, er);
		  System.out.println("In b");
		
	  }
	  @Test(priority=3)
	  public void a() {
		  SoftAssert sa=new SoftAssert();
		  String ar="noida",er="noida1";
			sa.assertEquals(ar, er);
		  System.out.println("In a");
		  sa.assertAll();
		  
	  }
}
