package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY4.data;
import SDAY4.login;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class NewTest5 {
	
	
		login t;
		data d;
	
	@BeforeClass
	public void config() {
		 t=new login();
	 d=new data();

	}
  @Test(dataProvider = "dp")
  public void t1(String u,String p,String s) {
	 System.out.println(u+"\n"+p+"\n"+s);
	 d.uid=u;
	 d.pwd=p;
	 d.exp_res=s;
	 data d1=login.llogin(d);
	 SoftAssert sa=new SoftAssert();
	 sa.assertEquals(d.exp_res, d1.actual_res);
	 sa.assertAll();
	  
  }

  @DataProvider(name="dp")
  public String[][] getData() {
    String[][] data= {
       { "cobrakai123@gmail.com", "123456","Success" },
       { "hh@gmail.com","dsddgsg" ,"Failure" }
    };
    return data;
  }
}
