package SDAY4;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {

	public static data llogin(data d) {

		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.name("Email")).sendKeys(d.uid);
		dr.findElement(By.name("Password")).sendKeys(d.pwd);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		boolean f=dr.getTitle().contains("Login");
		if(!f) {
			d.actual_res="Pass";
			d.status="PASS";
			
			System.out.println("Login Successfull");
			dr.findElement(By.className("ico-logout")).click();
			dr.close();
		}
		else {
			d.actual_res="Failure";
			d.actual_em1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			d.actual_em2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			System.out.println("Exp_em1:-  "+d.exp_em1+"\n"+"Exp_em2:-  "+d.exp_em2);
			dr.close();
		
		}
		
	
		if(d.actual_res.equals(d.exp_res)){
			if(d.exp_em1==null&&d.exp_em2==null&&d.actual_em1==null&&d.actual_em2==null)
			{
				d.status="PASS";
			}
			else	if(d.actual_em1.equals(d.exp_em1)&&d.actual_em2.equals(d.exp_em2)) {
			
					d.status="PASS";
				}
				else
					d.status="Failure";
				
			
		}
			else {
				d.status="Failure";
			}
		
	
return d;
	}

	public static void main(String[] args) {
		excel_io io=new excel_io();
		int c=1;
		ArrayList<data>arr=io.read_excel();
		for(data d1:arr) {
			System.out.println(d1.uid);
			System.out.println(d1.pwd);
			
		data a1=llogin(d1);
		io.write(a1,c);
		c++;
		}
//		for(data d:a1) {
//			System.out.println(d.actual_em1);
//			System.out.println(d.actual_em2);
//			System.out.println(d.actual_res);
//			System.out.println(d.status);
//		}
		

	}

}
