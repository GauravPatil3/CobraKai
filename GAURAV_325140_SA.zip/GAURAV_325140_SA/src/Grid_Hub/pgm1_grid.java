package Grid_Hub;
import java.net.MalformedURLException;
import java.net.URL;
import org.testng.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
public class pgm1_grid {

	
	String autURL,nodeURL;
	
	@BeforeClass
	public void setup() throws MalformedURLException{
		autURL="https://www.facebook.com";
		nodeURL="http://172.16.29.171:5566/wd/hub";
		
	}
	
	@Test
	public void t1()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		autURL="https://www.facebook.com";
		nodeURL="http://172.16.29.171:5566/wd/hub";
		DesiredCapabilities cap=DesiredCapabilities.chrome();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		try {
			dr=new RemoteWebDriver(new URL(nodeURL), cap);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		dr.get("https://www.facebook.com");
		dr.findElement(By.id("email")).sendKeys("Fuck You");
	}
}
