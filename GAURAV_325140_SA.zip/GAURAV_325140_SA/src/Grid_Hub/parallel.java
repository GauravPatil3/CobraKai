package Grid_Hub;

import org.testng.annotations.Test;

public class parallel {

	@Test
	public void t1() {
		System.out.println("In t1");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Stop t1");
	}
	@Test
	public void t2() {
		System.out.println("In t2");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Stop t2");
	}

}
