package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",glue="STEP_DEF",tags="Round2",
				 plugin="html:reports/cucumber-report")
public class testrunner extends AbstractTestNGCucumberTests {

}
