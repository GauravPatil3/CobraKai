package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm1 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		dr.findElement(By.id("email")).sendKeys("7030768769");
		dr.findElement(By.id("pass")).sendKeys("gaurav@2");
		//dr.findElement(By.xpath("//*[@id=\"u_0_b\"]")).click();
		dr.findElement(By.id("u_0_b")).click();

	}

}
