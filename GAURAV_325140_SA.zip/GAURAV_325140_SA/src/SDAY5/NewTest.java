package SDAY5;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class NewTest {
  @BeforeMethod
  
  public void a() {
	  System.out.println("Hello");
  }
  @Test
  public void t1() {
	  System.out.println("I met Mr. Dhoni");
  }
  @AfterMethod
  public void c() {
	  System.out.println("Bye");
	  
  }
  @Test
  public void t2() {
	  System.out.println("I had my lunch with Mr. Virat Kohli");
	 
  }
  @Test
  public void t3() {
	  System.out.println("I took a pic with Mr. Rohit Sharma");
	 
  }

  @BeforeClass
  public void beforeClass() {
	  System.out.println("I came to cricket stadium");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("Now I am back Home");
  }

}
