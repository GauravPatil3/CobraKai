package SDAY5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io {
	

	public ArrayList<data> read_excel(){
		ArrayList<data> arr=new ArrayList<data>();
		
		try {
			File f=new File("LOGIN.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			for(int i=1;i<=sh.getLastRowNum();i++)
			{
				data d=new data();
			XSSFRow r1=sh.getRow(i);
			XSSFCell c1=r1.getCell(0);
			d.uid=c1.getStringCellValue();


			XSSFCell c2=r1.getCell(1);
			int n=c2.getCellType();
			if(n==1)
			d.pwd=c2.getStringCellValue();
			else {
			int t=(int)c2.getNumericCellValue();
			d.pwd= Integer.toString(t);
			}
			//System.out.println(d.pwd);
			XSSFCell c3=r1.getCell(2);
			d.exp_res=c3.getStringCellValue();
			//XSSFCell c4=r1.getCell(3);
			if(r1.getCell(3)==null||r1.getCell(3).getCellType()==Cell.CELL_TYPE_BLANK) {
				d.exp_em1=null;
			}else
				d.exp_em1=r1.getCell(3).getStringCellValue();
			
			if(r1.getCell(4)==null||r1.getCell(4).getCellType()==Cell.CELL_TYPE_BLANK) {
				d.exp_em2=null;
			}else
				d.exp_em2=r1.getCell(4).getStringCellValue();
			
			arr.add(d);
			
			}

			
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return arr;
	}
	public void write(ArrayList<data>arr) {
		File f=new File("LOGIN.xlsx");
		try {
			
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			int row=1;
for(data d:arr)
{
			XSSFRow r1=sh.getRow(row);
			XSSFCell c1=r1.createCell(5);
			c1.setCellValue(d.actual_res);
			XSSFCell c2=r1.createCell(6);
			c2.setCellValue(d.actual_em1);
			
			XSSFCell c3=r1.createCell(7);
			c3.setCellValue(d.actual_em2);
			XSSFCell c5=r1.createCell(8);
			c5.setCellValue(d.status);
			
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
			row++;
}		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}

