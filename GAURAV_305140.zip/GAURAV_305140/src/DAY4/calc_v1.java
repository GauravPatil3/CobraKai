package DAY4;

public class calc_v1 {

public int add(int a1,int b1) {
	return a1+b1;
}
		
	public float add(float f1,float f2) {
		return f1+f2;
	}
	public float add(float f1,int f2) {
		return f1+f2;
	}

}
