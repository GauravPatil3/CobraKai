package Saturaday;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a1[]= {12,15,18,21,24,27,30};
		int a2[]= {10,15,20,25,30};
		System.out.println("First"+" "+"Second "+" "+"Sum");
		for(int i=0;i<a1.length;i++) {
			for(int j=0;j<a2.length;j++) {
				if((a1[i]+a2[j])>30&&(a1[i]+a2[j])<40) {
					int sum=a1[i]+a2[j];
					System.out.println(a1[i]+"    "+a2[j]+"      "+sum);
				}
			}
		}
		
	}

}
