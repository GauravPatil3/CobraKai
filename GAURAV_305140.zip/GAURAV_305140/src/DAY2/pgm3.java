package DAY2;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int sum=0;
int cnt=0;
		for(int i=10;i<=50;i++)
		{
			if(i%5==0)
				{
				sum=sum+i;	
				cnt++;
				if(cnt==1)
			System.out.print(i);
				else
					System.out.print("+" +i);
				}
		}
		System.out.print("=");
		System.out.print(sum);
	}
	

}
