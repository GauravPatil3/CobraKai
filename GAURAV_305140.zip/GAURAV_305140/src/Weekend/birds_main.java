package Weekend;

public class birds_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parrot p1 = new parrot(59,3000,80,"Yellow","fruits","kakapo",2);
		parrot p2 = new parrot(62,4000,40,"Crimpson Red","seeds","Macaw",2);
		parrot p3 = new parrot(8,12,20,"Red","insects","Pygmy",2);
	owl o1 = new owl(40,620,3,"White","squirrels","Barn",2);
		owl o2= new owl(70,2000,4,"Black","insects","Eurasian",2);
		
		p1.display();
		p1.eats();
		p1.flys();
		p2.display();
		p2.imitate();
		p2.flys();
		p3.display();
		p3.eats();
		p3.screams();
		
		o1.display();
		o1.eats();
		o1.rotatesneck();
		o2.display();
		o2.hunts();
		
		

	}

}
