package Weekend;

public class product {
public int pid,unit_rate,units,price;
public String p_name,p_grade;


public int Price(int rate,int unit) {
	return rate*unit;
}


public String Grade(int price2) {
	if(price2<25000)
		return "A";
	else
		return"B";
}
}
