package Weekend;



public class birds {
	
	int nol,age;
	String color;
	String food;
	String name;
	
	
	
	public void flys() {
		System.out.println("The Bird Flys\n");
	}
	
	public void eats() {
		System.out.println("The Bird eats\n");
	}	
	
	public void display() {
		System.out.println(" No of legs: " +this.nol + " Skin color: "+ this.color + " Food: " + this.food + " Name: "+this.name 
							+" Age: " + this.age );
	}
	
}
