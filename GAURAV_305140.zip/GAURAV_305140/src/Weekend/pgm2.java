package Weekend;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm2 {

	public static ArrayList<product >read_excel(){
		ArrayList<product > arr=new ArrayList<product>();
		
		try {
			File f=new File("C:\\Users\\gaurav.patil\\Documents\\Product.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			
			for(int i=1;i<=sh.getLastRowNum();i++) {
				product p=new product();
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(0);
			p.pid=(int) c.getNumericCellValue();
			XSSFCell c1=r.getCell(1);
			p.p_name=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			p.unit_rate=(int)c2.getNumericCellValue();
			XSSFCell c3=r.getCell(3);
			p.units=(int) c3.getNumericCellValue();
			
			
			p.price=p.Price(p.unit_rate, p.units);
		
			p.p_grade=p.Grade(p.price);
			
			arr.add(p);
			
		} 
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return arr;	
	}
	
	public static void write_excel(ArrayList<product> arr) {
		int i=1;
		for(product p:arr) {
		try {
			File f=new File("C:\\Users\\gaurav.patil\\Documents\\Product.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("sheet1");
			 
				
			XSSFRow r=sh.getRow(i);
			XSSFCell c4=r.createCell(4);
			c4.setCellValue(p.price);
			
			XSSFCell c5=r.createCell(5);
			c5.setCellValue(p.p_grade);
			
			FileOutputStream fos= new FileOutputStream(f);
			wb.write(fos);
			}
			catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		i++;
		}
	}
	public static void main(String[] args) {
		ArrayList<product>arr=read_excel();
		write_excel(arr);
		
		
		
	}

}
