package Weekend;

public class student {

	int rollno,java,selenium;
	String name;
	float avg;
	public student(int i, String string, int j, int k) {
		this.rollno=i;
		this.name=string;
		this.java=j;
		this.selenium=k;
		// TODO Auto-generated constructor stub
	}
	public float average() {
		
		// TODO Auto-generated method stub
	this.avg= (this.java+this.selenium)/2;
	return avg;
		
	}



}
