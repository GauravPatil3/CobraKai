package Weekend;

import java.util.ArrayList;

public class pgm1 {

	static ArrayList<String>get_each_word(String str){
		ArrayList<String>arr=new ArrayList<String>();
		int p=0,i=0;
		while(p!=-1) {
			p=str.indexOf(" ",p+1);
			if(p!=-1)
			{
				arr.add(str.substring(i,p));
				i=p;
			}
		}
		arr.add(str.substring(i,str.length()));
		
		
		return arr;
	}
	
	static ArrayList<String>count_vowels(ArrayList<String> s){
		ArrayList<String>arr1=new ArrayList<String>();
		int cnt=0;
	
		for(int i=0;i<s.size();i++) {
			String st=s.get(i).toString();
			char[] str=st.toCharArray();
			for(int j=0;j<str.length;j++) {
				
				if(str[j]=='a'||str[j]=='e'||str[j]=='i'||str[j]=='o'||str[j]=='u') {
					cnt++;
				}
			}
			if(cnt>=3) {
				arr1.add(st);
				cnt=0;
			}
			cnt=0;
		}
		
		return arr1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String line="I have learnt loops, oops concepts, iheritance, exception handlinng, arraylist and string handling";
	    String line2=line.replace(",","");
	    ArrayList<String> arr=get_each_word(line2);
	   
	    ArrayList<String> arr1= count_vowels(arr);
	
	    System.out.println(arr1);
	
	}

}
