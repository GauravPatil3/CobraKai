package DAY1;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int english=70,maths=71,physics=76;
		float avg=(english+maths+physics)/3;
		
		if(avg>=60)
			System.out.println("First Class  ");
		else if(avg>=50&avg<60)
			System.out.println("Second Class ");
		else if(avg>=35&avg<50)
			System.out.println("Pass");
		else
				System.out.println("Failed ");
		
	}

}
