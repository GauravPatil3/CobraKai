package DAY1;

public class pgm1 {

	static void prime()
	{
	int i;
	int flag=1;
	int sum=2;
	int cnt=8;
	System.out.println("First 10 Prime Numbers are:");
	System.out.println("2");
	for(i=3; cnt>=0 ;i++)
	{
		for(int j=2; j<(i-1)/2+1 ;j++)
		{
			 if(i%j!=0)
			 {
				 flag=1;
			 }
			 else {
				 flag=0;
				 break;
			 }
		//2+3+5+7+11+13+17+19+23+29	 
		}
		if(flag==1)
		{
			
			if(cnt>=0)
			sum=sum+i;
			cnt--;
			System.out.println(i);	
		}
		flag=0;
		
		
	}
	System.out.println("Sum is:"+sum);
	}
	
	public static void main(String[] args) {
	
		prime();
		
	}

}
