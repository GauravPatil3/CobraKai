package Weekend;


public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[5];
		int num,rem,l=1000, sum = 0;
		int c=0;
		System.out.print(" Armstrong numbers");
		for (int i = 1; i <= l; i++)
		{
			num = i;
			while (num > 0)
			{
				rem = num % 10;
				sum = sum + (rem*rem*rem);
				num = num / 10;
			}
	 
			if (sum == i)
			{
				arr[c]=i;
				c++;
			}
			sum = 0;
			
		}
		for(int i=0;i<5;i++) {
			System.out.println(arr[i]);
		}
		

	}

}
/*import java.lang.Math; 

class GFG 
{ 
    
//Function to find Nth Armstrong Number 
static int NthArmstrong(int n) 
{ 
  int count = 0; 
    
  // upper limit from integer  
  for(int i = 1; i <= Integer.MAX_VALUE; i++) 
  { 
      int num = i, rem, digit = 0, sum = 0; 
        
      //Copy the value for num in num  
      num = i; 
        
      // Find total digits in num  
      digit = (int) Math.log10(num) + 1; 
        
      // Calculate sum of power of digits  
      while(num > 0) 
      {  
          rem = num % 10; 
          sum = sum + (int)Math.pow(rem, digit); 
          num = num / 10; 
      } 
        
      // Check for Armstrong number  
      if(i == sum) 
          count++; 
      if(count == n) 
          return i; 
  } 
  return n; 
} 

//Driver Code 
public static void main(String[] args) 
{ 
  int n = 12; 
  System.out.println(NthArmstrong(n)); 
} 
} */