package Saturaday;

public class pgm2 {

	public static void main(String[] args) {
		
		int cnt=0;
		for(int i=10;i<=30;i++) {
			if(i%5==0) {
				cnt++;
				
			}
		}	
		int a1[]=new int[cnt];
		for(int j=0, i=10;j<cnt&&i<=30;i++) {
			if(i%5==0) {
				a1[j]=i;
				System.out.print(a1[j]+ " ");
				j++;
			}
		}

	}

}
