package Saturaday;

public class pgm4 {

	public static String[] extract_word(String str) {
		int p=0,cnt=0,index=0,a=0,i=0;
		while(p!=-1) {
			p=str.indexOf(" ",p+1);
			cnt++;
		}
		String arr[]=new String[cnt];
		while ((index = str.indexOf(' ', index + 1)) > 0) {
			
			arr[i]=str.substring(a,index);
			a=index+1;
			i++;
			
		}
		arr[i]=str.substring(a, str.length());
		
		return arr;
	}
	public static void count_print(String[] arr) {
		// TODO Auto-generated method stub
		for(String out:arr) {
			if(out.length()>5) {
				System.out.println(out);
			}
		}
	}
	public static void main(String[] args) {
		String str="Hello I am Working at Global Logic";
		String[] arr=extract_word(str);
		System.out.println("Words having more than 5 Characters:");
		count_print(arr);
	}
	

}
