package DAY4;

public class calc_test {

	public static void main(String[] args) {
	  

		calc_v1 cc=new calc_v1();
		System.out.println(cc.add(2, 3));
		System.out.println(cc.add(2.6f, 3.3f));
		System.out.println(cc.add(2.9f, 3));

	}

}
