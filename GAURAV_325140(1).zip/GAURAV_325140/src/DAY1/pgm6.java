package DAY1;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b=20;
		int a=5;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
		
	}

}
