package DAY1;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Smallest
		int num1=5,num2=3,num3=1;
		if(num1<num2 && num1<num3)
			System.out.println(num1+"is Smaller");
		else
			if(num2<num3)
				System.out.println(num2+"is Smaller");
			else
				System.out.println(num3+"is Smaller");
				
		//Largest
		  if(num1>num2 && num1>num3){    
			  System.out.println(num1+"is largest");
	    }
	    else if(num2>num3){
	    	 System.out.println(num2+"is largest");}
	    else{
	        System.out.println(num3+"is largest");
	}

}
}
