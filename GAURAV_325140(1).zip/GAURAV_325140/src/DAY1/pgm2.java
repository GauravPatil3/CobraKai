package DAY1;

import java.util.Scanner;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Numer:");
		int num=sc.nextInt();
		int t,sum=0,mod;
		t=num;
		while(t>0)
		{
			mod=t%10;
			sum=sum*10+mod;
			t=t/10;
			
		}
	if(sum==num)
	{
		System.out.println("Palindrome");
	}
	else {
		System.out.println("not a palindrome");
	}
	
	sc.close();	

	}
	

}
