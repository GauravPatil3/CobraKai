package DAY3;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {21,34,91,59,16,44,29,36,49,82};
		
		for(int i=0;i<num.length;i++) {
			for(int j=i+1;j<num.length;j++) {
				if(num[i]+num[j]==65) {
					System.out.println("sum of "+num[i]+" & "+num[j]+ " is = 65");
				}
			}
		}
	}

}
