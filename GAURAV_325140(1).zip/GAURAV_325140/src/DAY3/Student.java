package DAY3;

public class Student {
int rollno,m1,m2;
String name;
float avg;
public void average(int m1,int m2) {
	
	 avg=(float)(m1+m2)/2;
	System.out.println("Average is:"+avg);
	System.out.println();
}
}
