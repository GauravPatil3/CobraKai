package DAY2;

import java.util.Scanner;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num,sum=0;
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		int temp=num;
		while(num>0) {
			temp=num%10;
			if(temp>5) {
				sum=sum+temp;
			}
			num=num/10;
		}
		System.out.println(sum);
		sc.close();
	}

}
