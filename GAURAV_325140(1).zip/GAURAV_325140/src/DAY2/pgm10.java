package DAY2;

public class pgm10 {

	private static boolean isprime(int k) {
	int flag=0;
		
	if(k==2||k==3)
		return true;
		for(int j=2; j<(k-1)/2+1;j++)
		{

			 if(k%j!=0)
			 {
				 flag=1;
			 }
			 else {
				 flag=0;
				 break;
			 } 
		}
		if(flag==1)
			return true;
		else
			return false;
		
	}
	public static void main(String[] args) {
		
		int n=1,i=2,sum=0;
		System.out.println("First 10 Prime Numbers are:");
		while(n<=10)
		{
			if(isprime(i)) {
				sum=sum+i;
				System.out.print(i+" ");
				n++;
			}
			i++;
		}
		System.out.println();
		System.out.println("Sum is:"+sum);

	}

}
