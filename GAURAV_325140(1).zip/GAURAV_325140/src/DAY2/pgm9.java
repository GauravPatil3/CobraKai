package DAY2;

public class pgm9 {

	private static int add(int i, int j) {
		int z=i+j;
		return z;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=5,b=9;
		int c=add(a,b);
		System.out.println(c);
	}
	
}
